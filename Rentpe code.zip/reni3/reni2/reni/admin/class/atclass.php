<?php

$host="localhost";
$user= "root";
$password= "";
$database="db_rent";

$connection = mysqli_connect($host,$user,$password,$database);