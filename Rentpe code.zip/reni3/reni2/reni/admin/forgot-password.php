 <?php
	session_start();
	require './class/atclass.php';

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;

	include '../vendor/autoload.php';

	if ($_POST) {
		$email = $_POST['email'];
		$q = mysqli_query($connection, "select * from tbl_admin where email='{$email}'");
		$count = mysqli_num_rows($q);
		if ($count == 1) {
			$data = mysqli_fetch_array($q);
			// echo $data['password'];
			$msg = "Hello Your password is " . $data['password'];

			//Load Composer's autoloader
			//require 'vendor/autoload.php';

			//Create an instance; passing true enables exceptions
			$mail = new PHPMailer(true);

			try {
				//Server settings
				//$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
				$mail->isSMTP();                                            //Send using SMTP
				$mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
				$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
				$mail->Username   = 'poojanprajapati282@gmail.com';                     //SMTP username
				$mail->Password   = 'pedq fqzz sreb ejyu';                               //SMTP password
				$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
				$mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

				//Recipients
				$mail->setFrom('poojanprajapati282@gmail.com', 'Mailer');
				$mail->addAddress($email, 'Joe User');     //Add a recipient

				//Content
				$mail->isHTML(true);                                  //Set email format to HTML
				$mail->Subject = 'Forgot password';
				$mail->Body    = $msg;
				$mail->AltBody = $msg;

				$mail->send();
				echo "<script>alert('Password sent on your email');</script>";
			} catch (Exception $e) {
				echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
			}
		} else {
			echo "<script>alert('Email not found')</script>";
		}
	}
	// exit();
	?>
	<!DOCTYPE HTML>
	<html>
	<head>
	<title>Glance Design Dashboard an Admin Panel Category Flat Bootstrap Responsive Website Template | Forms :: w3layouts</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	
	<!-- Bootstrap Core CSS -->
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
	
	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	
	<!-- font-awesome icons CSS -->
	<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- //font-awesome icons CSS -->
	
	 <!-- side nav css file -->
	 <link href='css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
	 <!-- side nav css file -->
	 
	 <!-- js-->
	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/modernizr.custom.js"></script>
	
	<!--webfonts-->
	<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
	<!--//webfonts--> 
	
	<!-- Metis Menu -->
	<script src="js/metisMenu.min.js"></script>
	<script src="js/custom.js"></script>
	<link href="css/custom.css" rel="stylesheet">
	<!--//Metis Menu -->
	
	
	</head>
	<!-- Font Awesome Icons -->
	<link href="css/font-awesome.css" rel="stylesheet">
	
	<!-- Google Fonts -->
	<link href="//fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
	
	<style>
		body {
			font-family: 'PT Sans', sans-serif;
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
			background-color: #f4f4f4;
			margin: 0;
		}
	
		.login-container {
			background: #fff;
			padding: 30px;
			border-radius: 10px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
			width: 350px;
			text-align: center;
		}
	
		.login-container h2 {
			margin-bottom: 20px;
			color: #333;
		}
	
		input {
			width: 100%;
			padding: 10px;
			margin: 10px 0;
			border: 1px solid #ccc;
			border-radius: 5px;
			font-size: 16px;
		}
	
		input[type="submit"] {
			background-color: #288ca7;
			color: white;
			border: none;
			cursor: pointer;
			padding: 12px;
			font-size: 18px;
			font-weight: bold;
		}
	
		input[type="submit"]:hover {
			background-color: #1b6b88;
		}
	
		.error {
			color: red;
			font-size: 14px;
		}
	</style>
	
	<body class="cbp-spmenu-push"  style='background-color:gray;'>
		<div class="main-content" >
		
		 
			<!-- //header-ends -->
			 <!-- main content start-->
			<div id="page-wrapper">
				<div class="main-page">
					<div class="forms">
						<center><h1>Admin Panel Forgot Password</h1></center>
						 
						<div class=" form-grids row form-grids-right">
							<div class="widget-shadow " data-example-id="basic-forms"> 
				
							
							
	
							
			<form method="post" id="myform">
				Email:<input type="email" name="email" required/>
				
				
				<input type="Submit"/>
				
				<center><a href="forgot-password.php">Forgot-Password ?</a></center>
	
				
			<!--footer-->
	
			<?php
	
			include './themepart/footer.php';
	
			?>
	
			<!--//footer-->
		</div>
		
		<!-- side nav js -->
		<script src='js/SidebarNav.min.js' type='text/javascript'></script>
		<script>
		  $('.sidebar-menu').SidebarNav()
		</script>
		<!-- //side nav js -->
		
		<!-- Classie --><!-- for toggle left push menu script -->
			<script src="js/classie.js"></script>
			<script>
				var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
					showLeftPush = document.getElementById( 'showLeftPush' ),
					body = document.body;
					
				showLeftPush.onclick = function() {
					classie.toggle( this, 'active' );
					classie.toggle( body, 'cbp-spmenu-push-toright' );
					classie.toggle( menuLeft, 'cbp-spmenu-open' );
					disableOther( 'showLeftPush' );
				};
				
				function disableOther( button ) {
					if( button !== 'showLeftPush' ) {
						classie.toggle( showLeftPush, 'disabled' );
					}
				}
			</script>
		<!-- //Classie --><!-- //for toggle left push menu script -->
		
		<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
		
		<!-- Bootstrap Core JavaScript -->
	   <script src="js/bootstrap.js"> </script>
	   <script src="jquery-3.7.1.js"></script>
	<script src="jquery.validate.js"></script>
	<style>
		.error {
		  color: red;
		  font-size: 12px;
		}
		input, button {
		  margin: 10px 0;
		}
	  </style>
	<script>
		$(document).ready(function(){
		   $("#myform").validate();
		});
	</script>
	</body>
	</html>
	   
	</body>
	</html>