<?php

require './class/atclass.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include '../vendor/autoload.php';

if ($_POST) {
    $email = $_POST['email'];
    $q = mysqli_query($connection, "select * from tbl_admin where email='{$email}'");
    $count = mysqli_num_rows($q);
    if ($count == 1) {
        $data = mysqli_fetch_array($q);
        echo $data['password'];
        $msg = "Hello Your password is " . $data['password'];

        //Load Composer's autoloader
        //require 'vendor/autoload.php';

        //Create an instance; passing true enables exceptions
        $mail = new PHPMailer(true);

        try {
            //Server settings
            //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'poojanprajapati282@gmail.com';                     //SMTP username
            $mail->Password   = 'pedq fqzz sreb ejyu';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS

            //Recipients
            $mail->setFrom('poojanprajapati282@gmail.com', 'Mailer');
            $mail->addAddress('mehtafalak14@gmail.com', 'Joe User');     //Add a recipient

            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Forgot password';
            $mail->Body    = $msg;
            $mail->AltBody = $msg;

            $mail->send();
            echo "<script>alert('Password sent on your email');</script>";
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "<script>alert('Email not found')</script>";
    }
}
?>
<html>

<body>
    <form method="post">
        Email : <input type="email" name="email" />
        <input type="submit" />

    </form>
</body>

</html>