<?php
require './class/atclass.php';
$msg = " ";

if($_POST)
{
	$order_id = mysqli_real_escape_string($connection,$_POST['order_id']);
    $product_id= mysqli_real_escape_string($connection,$_POST['product_id']);
    $oquantity = mysqli_real_escape_string($connection,$_POST['oquantity']);
    $oamount= mysqli_real_escape_string($connection,$_POST['oamount']);
    $oduration = mysqli_real_escape_string($connection,$_POST['0duration']);

$query = mysqli_query($connection,"insert into tbl_order_details(order_id,product_id,quantity,amount,duration) values('{$order_id}','{$product_id}','{$oquantity}','{$oamount}','{$oduration}')") or die (mysqli_error($connection)); 

if($query)
{
    $msg = '<div class="alert alert-success" role="alert">
    Record Added!
    </div>';
}
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Glance Design Dashboard an Admin Panel Category Flat Bootstrap Responsive Website Template | Forms :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>

<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS -->

 <!-- side nav css file -->
 <link href='css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
 <!-- side nav css file -->
 
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->

</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
	
		<!--left-fixed -navigation-->
		<?php
        include './themepart/sidebar.php';
        ?>
		<!-- header-starts -->
		<?php
        include './themepart/header.php';
        ?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h2 class="title1">Order Details</h2>
                    <?php
                        echo $msg;
                        ?>
					<div class=" form-grids row form-grids-right">
						<div class="widget-shadow " data-example-id="basic-forms"> 
            
							<div class="form-title">
								<h4>Order Details Information :</h4>
							</div>
							
							<div class="form-group">
							<form class="form-horizontal" id="myform" method="post" enctype="multipart/form-data">
							<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Order_id</label>
							<div class="col-sm-9">
							<?php 
                             $cq = mysqli_query($connection, "select * from tbl_order_master") or die(mysqli_error($connection));
                             echo "<select name='order_id' class='form-control'>";
                             while($catrow = mysqli_fetch_array($cq)){
                             echo "<option value='{$catrow['order_id']}'>{$catrow['order_id']}</option>";
                            echo "<option value=''>Select</option>";
                            }
                            echo "</select>";
                            ?>
							</div>
						    </div>

							<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Product_id</label>
							<div class="col-sm-9">
							<?php 
                             $cq = mysqli_query($connection, "select * from tbl_product") or die(mysqli_error($connection));
                             echo "<select name='product_id' class='form-control'>";
                             while($catrow = mysqli_fetch_array($cq)){
                             echo "<option value='{$catrow['product_id']}'>{$catrow['product_id']}</option>";
                            echo "<option value=''>Select</option>";
                            }
                            echo "</select>";
                            ?>
							</div>
						    </div>
							
							<div class="form-group"> 
                            <label for="inputEmail3" class="col-sm-2 control-label">Quantity</label>
                            <div class="col-sm-9"> 
                            <input type="text" class="form-control"  name="oquantity" placeholder="Enter a quantity" required> 
                            </div> 
                            </div> 

							<div class="form-group"> 
                            <label for="inputEmail3" class="col-sm-2 control-label">Amount</label>
                            <div class="col-sm-9"> 
							<input type="text" class="form-control"  name="oamount" placeholder="Enter a amount" required> 
                            </div> 
                            </div>

                            <div class="form-group"> 
                            <label for="inputEmail3" class="col-sm-2 control-label">Duration</label>
                            <div class="col-sm-9"> 
                            <input type="password" class="form-control"  name="oduration" placeholder="Enter a duration" required> 
                            </div>
                            </div> 

                                   
                            <div class="col-sm-offset-2"> 
                            <button type="submit"class="btn btn-primary">Add </button> 
                            <button type="reset" class="btn btn-danger">Reset </button>
                            <button type="button" onclick="window.location='display-order_details.php';" class="btn btn-info">View </button> 
						    </div>
		       </div>
                    </form> 
							
				</div>
						    
			</div>
					          
		</div>


                                        
			
		<!--footer-->

		<?php

        include './themepart/footer.php';

        ?>

        <!--//footer-->
	</div>
	
	<!-- side nav js -->
	<script src='js/SidebarNav.min.js' type='text/javascript'></script>
	<script>
      $('.sidebar-menu').SidebarNav()
    </script>
	<!-- //side nav js -->
	
	<!-- Classie --><!-- for toggle left push menu script -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!-- //Classie --><!-- //for toggle left push menu script -->
	
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
   <script src="jquery-3.7.1.js"></script>
<script src="jquery.validate.js"></script>
<style>
    .error {
      color: red;
      font-size: 12px;
    }
    input, button {
      margin: 10px 0;
    }
  </style>
<script>
    $(document).ready(function(){
       $("#myform").validate();
    });
</script>
</body>
</html>
   
</body>
</html>