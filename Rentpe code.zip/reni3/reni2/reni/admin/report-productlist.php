<?php 
$connection = mysqli_connect("localhost","root","","db_rent");
?>
<html>
    <body>
        <center><h1>MyReporProject</h1></center>
        Date:<?php echo date('d-m-Y'); ?>
        <a href="#" onclick="window.print()">Print</a>
        <hr/>
    <center><h3>Product Report  </h3></center>


    <?php 
    $q = mysqli_query($connection,"select * from tbl_product");
    $count = mysqli_num_rows($q);
    echo "$count Records Found";
    echo "<table align='center' border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Name</th>";
    echo "<th>Price</th>";
    echo "</tr>";
    while($data = mysqli_fetch_array($q)){
        echo "<tr>";
        echo "<td>{$data['product_id']}</td>";
        echo "<td>{$data['product_name']}</td>";
        echo "<td>{$data['price']}</td>";
        echo "</tr>";
    }
    echo "</table>";

    ?>

    </body>
</html>