<?php 
$connection = mysqli_connect("localhost","root","","db_rent");
?>
<html>
    <body>
        <center><h1>MyReporProject</h1></center>
        Date:<?php echo date('d-m-Y'); ?>
        <a href="#" onclick="window.print()">Print</a>
        <hr/>
    <center><h3>Product Report  </h3></center>

    <form method="post">
    
    <?php 
    $cq = mysqli_query($connection,"select * from tbl_user");
    echo "<select name='uid'>";
    while($cdata = mysqli_fetch_array($cq)){
        echo "<option value='{$cdata['user_id']}'>{$cdata['user_name']}</option>";
    }
    echo "</select>";

    ?>

    <input value="Search" type="submit"/>
    </form>

    <?php 
    if($_POST){
        $cid = $_POST['uid'];
    $q = mysqli_query($connection,"select * from tbl_order_master where user_id ='{$cid}'");
    $count = mysqli_num_rows($q);
    echo "$count Records Found";
    echo "<table align='center' border='1'>";
    echo "<tr>";
    echo "<th>ID</th>";
    echo "<th>Date</th>";
    echo "<th>Status</th>";
    echo "</tr>";
    while($data = mysqli_fetch_array($q)){
        echo "<tr>";
        echo "<td>{$data['order_id']}</td>";
        echo "<td>{$data['date']}</td>";
        echo "<td>{$data['status']}</td>";
        echo "</tr>";
    }
    echo "</table>";
    }
    ?>

    </body>
</html>