<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html"><span class="fa fa-area-chart"></span> RentPe<span class="dashboard_text">Products On Rent</span></a>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header">MAIN NAVIGATION</li>
              <li class="treeview">
                <a href="home.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
			  <li class="treeview">
                <a href="#">
                <i class="fa fa-laptop"></i>
                <span>Products</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="product.php"><i class="fa fa-angle-right"></i> Add </a></li>
                  <li><a href="display-product.php"><i class="fa fa-angle-right"></i> View </a></li>
                </ul>
              </li>
            
              <li class="treeview">
                <a href="#">
                <i class="fa fa-edit"></i> <span>Add</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="admin.php"><i class="fa fa-angle-right"></i> Admin</a></li>
                  <li><a href="category.php"><i class="fa fa-angle-right"></i> Category</a></li>
                  <li><a href="subcategory.php"><i class="fa fa-angle-right"></i> SubCategory</a></li>
                  <li><a href="product.php"><i class="fa fa-angle-right"></i> Product</a></li>
                  <!-- <li><a href="user.php"><i class="fa fa-angle-right"></i> User</a></li>
                  <li><a href="cart.php"><i class="fa fa-angle-right"></i> cart</a></li>
                  <li><a href="order_master.php"><i class="fa fa-angle-right"></i> Order_Master</a></li>
                  <li><a href="order_details.php"><i class="fa fa-angle-right"></i> Order_Details</a></li>
                  <li><a href="payment.php"><i class="fa fa-angle-right"></i> Payment</a></li>
                  <li><a href="feedback.php"><i class="fa fa-angle-right"></i> Feedback</a></li> -->
                  

                </ul>
              </li>
              <li class="treeview">
                <a href="#">
                <i class="fa fa-table"></i> <span>Display</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="display-admin.php"><i class="fa fa-angle-right"></i> Admin</a></li>
                  <li><a href="display-category.php"><i class="fa fa-angle-right"></i> Category</a></li>
                  <li><a href="display-subcategory.php"><i class="fa fa-angle-right"></i> SubCategory</a></li>
                  <li><a href="display-product.php"><i class="fa fa-angle-right"></i> Product</a></li>
                  <li><a href="display-user.php"><i class="fa fa-angle-right"></i> User</a></li>
                  <li><a href="display-cart.php"><i class="fa fa-angle-right"></i> Cart</a></li>
                  <li><a href="display-order_master.php"><i class="fa fa-angle-right"></i> Order_Master</a></li>
                  <li><a href="display-order_details.php"><i class="fa fa-angle-right"></i> Order_Details</a></li>
                  <li><a href="display-payment.php"><i class="fa fa-angle-right"></i> Payment</a></li>
                  <li><a href="display-feedback.php"><i class="fa fa-angle-right"></i> Feedback</a></li>

                </ul>
              </li>
              
              <li class="treeview">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Reports</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                  <li><a href="report-feedback.php"><i class="fa fa-angle-right"></i> FeedBack</a></li>
                  <li><a href="report-product-price.php"><i class="fa fa-angle-right"></i> Product Price</a></li>
                  <li><a href="report-productcategory.php"><i class="fa fa-angle-right"></i>Product Category</a></li>
                  <li><a href="report-productlist.php"><i class="fa fa-angle-right"></i> Product List</a></li>
                  <li><a href="report-search-product.php"><i class="fa fa-angle-right"></i>Search Product</a></li>
                  <li><a href="report-user-order.php"><i class="fa fa-angle-right"></i>User Order</a></li>
                </ul>
              </li>
              <li class="header">Setting</li>
              <li><a href="changepassword.php"><i class="fa fa-angle-right text-red"></i> <span>Change Password</span></a></li>
              <li><a href="logout.php"><i class="fa fa-angle-right text-red"></i> <span>Logout</span></a></li>
               <!-- <li><a href="#"><i class="fa fa-angle-right text-red"></i> <span>Register</span></a></li> -->
              
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>