<?php
session_start();
require './admin/class/atclass.php';

// exit();
// login check
//if(!isset($_SESSION['uid']) )
//{
//header("location:login.php");
//}
// $q = mysqli_query($connection,"insert into tbl_cart(product_id,product_qty,user_id) values( '{$pid}','{$qty}','{$uid}')");
// header("location:view-cart.php");


if (isset($_POST["submit"])) {

    $pid = $_POST['product_id'];
    $qty = $_POST['qty'];
    $duration = $_POST['duration'];
    $uid = $_SESSION['id'];
    $query = mysqli_query($connection, "select * from tbl_cart where user_id='{$uid}' and product_id='{$pid}'") or die(mysqli_error($connection));

    $count = mysqli_num_rows($query);
    if ($count > 0) {
        // $_SESSION["failed_msg"]=   "Your product already exist in cart";

        echo "<script>alert('Your product already exist in cart');window.location='cart.php';</script>";
    } else {
        $pq = mysqli_query($connection, "SELECT * FROM tbl_product where product_id ='{$pid}'");
        $pdata = mysqli_fetch_array($pq);
        $total = $qty * $pdata['price'];
        $query1 = mysqli_query($connection, "insert into tbl_cart(product_id,quantity,user_id,amount,duration) values( '{$pid}','{$qty}','{$uid}','{$total}','{$duration}')") or die(mysqli_error($connection));
        if ($query1) {
            // $_SESSION["success_msg"]=   "Your product has been added to cart";
            echo "<script>alert('Your product has been added to cart');window.location='cart.php';</script>";
        }
    }
} else {
    header("location:login.php");
}
?>
?>