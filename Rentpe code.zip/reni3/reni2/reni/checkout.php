
<?php
session_start();
include('connection.php');
if (!isset($_SESSION['id'])) {
	header("location:login.php ");
}



//using new details
if ($_POST) {
	$name = mysqli_real_escape_string($connection, $_POST['name']);
	$mobile = mysqli_real_escape_string($connection, $_POST['mnumber']);
	$house = mysqli_real_escape_string($connection, $_POST['house']);
	$area = mysqli_real_escape_string($connection, $_POST['area']);
	$landmark = mysqli_real_escape_string($connection, $_POST['landmark']);
	$pincode = mysqli_real_escape_string($connection, $_POST['pincode']);
	$city = mysqli_real_escape_string($connection, $_POST['city']);
	$state = mysqli_real_escape_string($connection, $_POST['state']);
	$dstatus = "Pending";
	$ostatus = "Confirm";
	$pstatus = "Pending";
	$date = date('d-m-y');
	$address = $house . $area . $landmark . $city . $state;

	$uid = $_SESSION['id'];

	$oiq = mysqli_query($connection, "insert into tbl_order(user_id,order_date,order_status) values('{$uid}','{$date}','{$ostatus}') ") or die(mysqli_error($connection));
	//INSERT RECORD ID Order ID
	$orderid = mysqli_insert_id($connection);

	//order_details
	$ocq = mysqli_query($connection, "select * from tbl_cart where user_id ='{$uid}'");
	while ($ocd = mysqli_fetch_array($ocq)) {
		//cart data
		$pid = $ocd['product_id'];
		$qty = $ocd['product_qty'];
		//product data
		$pq = mysqli_query($connection, "select * from tbl_product where pro_id ='{$pid}'");
		$pdata =  mysqli_fetch_array($pq);
		$price = $pdata['price'];
		//order_details add
		$odq = mysqli_query($connection, "insert into tbl_orderdetails(order_id,product_id,quantity,price) values('{$orderid}','{$pid}','{$qty}','{$price}') ") or die(mysqli_error($connection));
		//cart delete
		mysqli_query($connection, "delete from tbl_cart where cart_id ='{$ocd['cart_id']}'");
	}
	$pmethod = "COD";
	$pp = 200000;
	$dquery = mysqli_query($connection, "insert into tbl_delivery(order_id,phone_number,delivery_address,delivery_status,pincode) values('{$orderid}','{$mobile}','{$address}','{$dstatus}','{$pincode}') ") or die(mysqli_error($connection));
	header("location:payment.php?oid=$orderid");
}
?>