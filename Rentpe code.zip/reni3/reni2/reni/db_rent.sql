-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2025 at 10:47 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_rent`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(5) NOT NULL,
  `admin_name` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `email`, `password`) VALUES
(1, 'Krisha Panchal', 'krishapanchal@gmail.com', ''),
(2, 'Falak Mehta', 'falak14@gmail.com', ''),
(3, 'Poojan Prajapati', 'prajapatipoojan2@gmail.com', ''),
(4, 'Priyanshi  Challa', 'priyanshi1@gmail.com', ''),
(5, 'Deven Thakkar', 'deven22@gmail.com', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cart_id` int(5) NOT NULL,
  `user_id` int(5) NOT NULL,
  `product_id` int(5) NOT NULL,
  `quantity` int(30) NOT NULL,
  `amount` int(20) NOT NULL,
  `duration` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `category_id` int(5) NOT NULL,
  `category_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`) VALUES
(1, 'Furniture'),
(2, 'Electronics'),
(3, 'Mattress'),
(4, 'Fitness');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(5) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(5) NOT NULL,
  `feedback_details` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_details`
--

CREATE TABLE `tbl_order_details` (
  `details_id` int(5) NOT NULL,
  `order_id` int(5) NOT NULL,
  `product_id` int(5) NOT NULL,
  `quantity` int(30) NOT NULL,
  `amount` int(20) NOT NULL,
  `duration` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_order_details`
--

INSERT INTO `tbl_order_details` (`details_id`, `order_id`, `product_id`, `quantity`, `amount`, `duration`) VALUES
(1, 1, 2, 1, 1000, ''),
(2, 1, 3, 1, 250, ''),
(3, 2, 17, 3, 780, '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_master`
--

CREATE TABLE `tbl_order_master` (
  `order_id` int(5) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(5) NOT NULL,
  `status` varchar(30) NOT NULL,
  `shipping_name` varchar(50) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `order_total` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_order_master`
--

INSERT INTO `tbl_order_master` (`order_id`, `date`, `user_id`, `status`, `shipping_name`, `mobile_no`, `address`, `order_total`) VALUES
(1, '2025-03-04', 3, 'pending', 'abc', 1234567899, '', ''),
(2, '2025-03-04', 3, 'pending', 'abc', 1234567899, '', '2340');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `payment_id` int(5) NOT NULL,
  `order_id` int(5) NOT NULL,
  `amount` int(20) NOT NULL,
  `method` varchar(50) NOT NULL,
  `details` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` int(5) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `details` text NOT NULL,
  `price` varchar(10) NOT NULL,
  `category_id` int(5) NOT NULL,
  `subcategory_id` int(5) NOT NULL,
  `duration` varchar(20) NOT NULL,
  `termscondition` text NOT NULL,
  `photopath` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `product_name`, `details`, `price`, `category_id`, `subcategory_id`, `duration`, `termscondition`, `photopath`) VALUES
(1, 'Single Bed', 'Space-Saving,  Sturdy Construction', '500 rs', 1, 1, '1 month', 'Sarkhu sachvjo', 'Singlebed.jpg'),
(2, 'Kingsize Bed', 'Crafted from high quality wood', '1000', 1, 1, '', 'sarkhu sachvjo', 'King Size bed.jpg'),
(3, 'Single door wardrobe', '3 Shelf configuration', '250', 1, 2, '', 'sarkhu sachvjo', 'Single door wardrobe.jpg'),
(4, 'Double door wardrobe', '6 section configuration', '600', 1, 2, '', 'sarkhu sachvjo', 'double door wardrobe.jpg'),
(5, 'Study Table', '1 drawer + 1 shelf configuration', '200', 1, 3, '', 'sarkhu sachvjo', 'Studytable.jpg'),
(6, 'Dinning table with 6 chairs', 'Includes 1 table + 6 chair', '12000', 1, 4, '', 'sarkhu sachvjo', 'Dining table (2).jpg'),
(7, 'Dinning table with 4 chairs', 'Sturdy large tabletop', '900', 1, 4, '', 'sarkhu sachvjo', 'dinning table with 4 chair.jpg'),
(8, '2-seater fabric Sofa', 'Soft Foam', '600', 1, 5, '', 'sarkhu sachvjo', '2 seater sofa.jpg'),
(9, 'L-shaped Fabric Sofa', 'Fully upholstered couch', '1200', 1, 5, '', 'sarkhu sachvjo', 'L shape sofa .jpg'),
(10, 'AC 2 TON', 'Convertible 5 in 1 mode', '2500', 2, 6, '', 'sarkhu sachvjo', 'AC 2 TON.jpg'),
(11, 'Single door Fridge', 'Capacity : 200-210L', '1000', 2, 7, '', 'sarkhu sachvjo', 'Single door fridge.jpg'),
(12, 'Double door fridge', 'Capacity : 230-250L', '1200', 2, 7, '', 'sarkhu sachvjo', 'Double door fridge.jpg'),
(13, 'Top-load Washing machine', 'Semi-Automatic , Capacity: 6 , Water proof panel', '700', 2, 8, '', 'sarkhu sachvjo', 'semi wahsing machine.jpg'),
(14, 'Front load Washing Machine', 'Capacity: 8 kg, Multiple wash modes', '1099', 2, 8, '', 'sarkhu sachvjo', 'Front load washing machine.jpg'),
(15, 'Microwave', 'Capacity : 20L, Used for Baking, Heating, Grilling & Cooking', '625', 2, 9, '', 'sarkhu sachvjo', 'Microwave.jpg'),
(16, 'Electric geyser', 'Tank Capacity: 3 to 5L', '560', 2, 10, '', 'sarkhu sachvjo', 'Electric geyser.jpg'),
(17, 'Gas Geyser', 'Tank Capacity: 4 to 6L', '780', 2, 10, '', 'sarkhu sachvjo', 'Gas geyser.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

CREATE TABLE `tbl_subcategory` (
  `subcategory_id` int(5) NOT NULL,
  `subcategory_name` varchar(50) NOT NULL,
  `category_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`subcategory_id`, `subcategory_name`, `category_id`) VALUES
(1, 'Bed', 1),
(2, 'Wardrobe', 1),
(3, 'Study Table', 1),
(4, 'Dinning table', 1),
(5, 'Sofa', 1),
(6, 'AC', 2),
(7, 'Refrigerator', 2),
(8, 'Washing Machine', 2),
(9, 'Microwave', 2),
(10, 'Gyser', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(5) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile_no` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `gender`, `email`, `password`, `mobile_no`) VALUES
(1, 'Kavya Raval', 'Female', 'Kavya11@gmail.com', '123', 2147483647),
(2, 'Kavya Raval', 'Female', 'Kavya11@gmail.com', '', 2147483647),
(3, 'abc', '', 'abc@gmail.com', '123', 1234567899),
(4, 'xyz', '', 'xyz@gmail.com', 'xyz', 2147483647),
(5, '', '', '', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  ADD PRIMARY KEY (`details_id`);

--
-- Indexes for table `tbl_order_master`
--
ALTER TABLE `tbl_order_master`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  ADD PRIMARY KEY (`subcategory_id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cart_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `category_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_feedback`
--
ALTER TABLE `tbl_feedback`
  MODIFY `feedback_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_order_details`
--
ALTER TABLE `tbl_order_details`
  MODIFY `details_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_order_master`
--
ALTER TABLE `tbl_order_master`
  MODIFY `order_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `payment_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_subcategory`
--
ALTER TABLE `tbl_subcategory`
  MODIFY `subcategory_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
