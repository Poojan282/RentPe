<?php
ob_start();
session_start();
require './admin/class/atclass.php';

if (!isset($_SESSION['id'])) {
  echo "<script>alert('Login Required');window.location='shop.php';</script>";
  // header("location:shop.php");
}

if (isset($_GET["pid"])) {
  $product_id = $_GET["pid"];
  //echo "select * from `tbl_product` where product_id='{$product_id}' order by product_id desc";
  $query_product = mysqli_query($connection, "select * from `tbl_product` where product_id='{$product_id}' order by product_id desc") or die(mysqli_error($connection));
  $count_product = mysqli_num_rows($query_product);


  if ($count_product > 0) {
    $row_product = mysqli_fetch_array($query_product);
  } else {
    header("location:shop.php");
  }
} else {
  header("location:shop.php");
}

?>
<!doctype html>
<html lang="en">

<!-- Mirrored from p.w3layouts.com/demosWTR/Freedom/04-01-2020/mend-freedom-demo_Free/540431521/web/ecommerce-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2025 08:50:46 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Mend Home Maintenance & Service Category Responsive Web Template - Ecommerce Single : W3Layouts</title>
  <!-- web fonts -->
  <link href="http://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900&amp;display=swap" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Pacifico&amp;display=swap&amp;subset=cyrillic,cyrillic-ext,latin-ext,vietnamese" rel="stylesheet">
  <!-- //web fonts -->
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-freedom.css">
</head>

<body>
  <script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
  <script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
  <script>
    (function() {
      if (typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
      }
    })();
  </script>
  <script>
    (function() {
      if (typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
      }
    })();
  </script>
  <script>
    (function() {
      if (typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
      }
    })();
  </script>
  <!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/w3layouts_V2/vdo.ai.js?vdo=34");</script>-->
  <div id="codefund"><!-- fallback content --></div>
  <script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src='https://www.googletagmanager.com/gtag/js?id=G-98H8KRKT85'></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-98H8KRKT85');
  </script>
  <meta name="robots" content="noindex">

  <body>
    <!-- Demo bar start -->
    <link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
    <!-- New toolbar-->
    <style>
      * {
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
      }


      #w3lDemoBar.w3l-demo-bar {
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 9999;
        padding: 40px 5px;
        padding-top: 70px;
        margin-bottom: 70px;
        background: #0D1326;
        border-top-left-radius: 9px;
        border-bottom-left-radius: 9px;
      }

      #w3lDemoBar.w3l-demo-bar a {
        display: block;
        color: #e6ebff;
        text-decoration: none;
        line-height: 24px;
        opacity: .6;
        margin-bottom: 20px;
        text-align: center;
      }

      #w3lDemoBar.w3l-demo-bar span.w3l-icon {
        display: block;
      }

      #w3lDemoBar.w3l-demo-bar a:hover {
        opacity: 1;
      }

      #w3lDemoBar.w3l-demo-bar .w3l-icon svg {
        color: #e6ebff;
      }

      #w3lDemoBar.w3l-demo-bar .responsive-icons {
        margin-top: 30px;
        border-top: 1px solid #41414d;
        padding-top: 40px;
      }

      #w3lDemoBar.w3l-demo-bar .demo-btns {
        border-top: 1px solid #41414d;
        padding-top: 30px;
      }

      #w3lDemoBar.w3l-demo-bar .responsive-icons a span.fa {
        font-size: 26px;
      }

      #w3lDemoBar.w3l-demo-bar .no-margin-bottom {
        margin-bottom: 0;
      }

      .toggle-right-sidebar span {
        background: #0D1326;
        width: 50px;
        height: 50px;
        line-height: 50px;
        text-align: center;
        color: #e6ebff;
        border-radius: 50px;
        font-size: 26px;
        cursor: pointer;
        opacity: .5;
      }

      .pull-right {
        float: right;
        position: fixed;
        right: 0px;
        top: 70px;
        width: 90px;
        z-index: 99999;
        text-align: center;
      }

      /* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

      #right-sidebar {
        width: 90px;
        position: fixed;
        height: 100%;
        z-index: 1000;
        right: 0px;
        top: 0;
        margin-top: 60px;
        -webkit-transition: all .5s ease-in-out;
        -moz-transition: all .5s ease-in-out;
        -o-transition: all .5s ease-in-out;
        transition: all .5s ease-in-out;
        overflow-y: auto;
      }

      /* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

      .hide-right-bar-notifications {
        margin-right: -300px !important;
        -webkit-transition: all .3s ease-in-out;
        -moz-transition: all .3s ease-in-out;
        -o-transition: all .3s ease-in-out;
        transition: all .3s ease-in-out;
      }



      @media (max-width: 992px) {
        #w3lDemoBar.w3l-demo-bar a.desktop-mode {
          display: none;

        }
      }

      @media (max-width: 767px) {
        #w3lDemoBar.w3l-demo-bar a.tablet-mode {
          display: none;

        }
      }

      @media (max-width: 568px) {
        #w3lDemoBar.w3l-demo-bar a.mobile-mode {
          display: none;
        }

        #w3lDemoBar.w3l-demo-bar .responsive-icons {
          margin-top: 0px;
          border-top: none;
          padding-top: 0px;
        }

        #right-sidebar,
        .pull-right {
          width: 90px;
        }

        #w3lDemoBar.w3l-demo-bar .no-margin-bottom-mobile {
          margin-bottom: 0;
        }
      }
    </style>

    </div>

    <?php
    include './themepart/header.php'
    ?>
    <!-- inner banner -->
    <section class="w3l-inner-banner-main">
      <div class="about-inner inner2">
        <div class="container seen-w3">
          <h3 class="inner-title">Rent Details</h3>
          <ul class="breadcrumbs-custom-path">
            <li><a href="index.html">Home</a></li>
            <li><span class="fa fa-angle-right" aria-hidden="true"></span></li>
            <li class="active">Rent Details</li>
          </ul>
        </div>
      </div>
    </section>
    <!-- //inner banner -->
    <div class="display-ad" style="margin: 8px auto; display: block; text-align:center;">
      <!---728x90--->

    </div>
    <!-- ecommerce single block -->
    <section class="w3l-ecommerce-single">
      <div class="ecommerce-page">
        <div class="container">
          <div class="row ecommerce-cart-two pt-2">
            <div class="col-md-4 cart-image">
              <a href="#" class="column-img" id="zoomIn">
                <figure>
                  <img src="admin/uploads/<?php echo $row_product["photopath"]; ?>" alt="product" class="img-responsive" />
                </figure>
              </a>
            </div>
            <div class="col-md-8 cart-details mt-md-0 mt-3">
              <h4><?php echo $row_product['product_name']; ?></h4>
              <div class="ratings">
                <ul class="star">
                  <li><a href="#star"><span class="fa fa-star" aria-hidden="true"></span></a>
                  </li>
                  <li><a href="#star"><span class="fa fa-star" aria-hidden="true"></span></a>
                  </li>
                  <li><a href="#star"><span class="fa fa-star" aria-hidden="true"></span></a>
                  </li>
                  <li><a href="#star"><span class="fa fa-star" aria-hidden="true"></span></a>
                  </li>
                  <li><a href="#star"><span class="fa fa-star-o" aria-hidden="true"></span></a>
                  </li>
                </ul>
              </div>
              <ul>
                <li>
                  <h6>Price Per Month:<?php echo $row_product['price']; ?></h6>
                </li>
                <li><br/> <br/> Minimum Duration: <?php echo $row_product['duration']; ?></li>
                <li>
                  <p></p>
                </li>
              </ul>
              <p class="single">Details:<?php echo $row_product['details']; ?></p>
              <p class="single">Terms:<?php echo $row_product['termscondition']; ?></p>
              <div class="sec-grid-1">
                <form method="post" action="cart-process.php">
                  <label>Quantity:</label>
                  <div class="disply-cont">
                    <input type="number" name="qty" value="1" min="1">
                  </div>

                  <label>Duration:</label>
                  <div class="disply-cont">
                    <select style="width:110px;" name="duration" id="duration">
                      <option>1 Month</option>
                      <option>3 Month</option>
                      <option>6 Month</option>
                      <option>12 Month</option>
                    </select>
                  </div>
              </div>
              <!-- <a href="ecommerce-cart.html" class="button raised hoverable"> -->
              <!-- <div class="anim"></div><span>Add to Cart</span> -->

              <input type="hidden" name="product_id" value="<?php echo $row_product["product_id"] ?>">
              <!-- <button type="submit" name="submit" class="item_add single-item hvr-outline-out button2">
                  <div class="anim"></div><span>Send Message</span>Add to cart
                </button> -->
              <div class="d-flex">
                <button type="submit" name="submit" class="button raised hoverable  ml-1">
                  <div class="anim"></div><span>Add to cart</span>
                </button>
              </div>
              </form>
              <!-- </a> -->
            </div>
          </div>
          <!-- <div class="text24-max-align mt-5">
            <h5 class="text24-heading">Product Decription</h5>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
              et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
              aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
              cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
              culpa qui officia deserunt mollit anim id est laborum.</p>
            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed
              quia non numquam eius modi tempora incidunt ut labore et dolore magnam </p>
            <div class="text24-list">
              <ol class="p-0">
                <li>Ut enim ad minima veniam, quis nostrum</li>
                <li class="gap-list">Exercitationem ullam corporis suscipit</li>
                <li>Nisi ut aliquid ex ea commodi consequatur</li>
              </ol>
            </div>
          </div> -->

          <?php
          if (isset($_POST['f_submit'])) {
            $date = $_POST['date'];
            $f_detail = $_POST['f_detail'];
            $user = $_SESSION['id'];

            $query = mysqli_query($connection, "insert into tbl_feedback(feedback_details,date,user_id) values('{$f_detail}','{$date}','{$user}')") or die(mysqli_error($connection));

            if ($query) {
              $msg = '<div class="alert alert-success" role="alert">
    FeedBack Added!
    </div>';
              header('location:details.php');
            }
          }
          ?>

          <section class="w3l-form1">
            <div class="form">
              <div class="section">
                <div class="d-grid content-sec">
                  <div class="form-left">
                    <div class="container">
                      <div class="sub-left-cont">
                        <div class="content-form p-md-5 p-4">
                          <div class="middle">
                            <h4>FeedBack</h4>
                          </div>
                          <form method="post" class="signin-form" id="myform">
                            <div class="form-input">
                               <input type="hidden" name='date' value="<?php echo date('d-m-y'); ?>"/>
                            </div>
                            <div class="form-input">
                              <!-- <input type="password" name="cpass" placeholder="Confirm Password" required /> -->
                              <textarea style="width:100%;height:80%;" name="f_detail"></textarea>
                            </div>
                            <!-- <label class="checkout">Remember me
                        <input type="checkbox">
                        <span class="checkmark"></span>
                      </label> -->
                            <button type="submit" name="f_submit" class="button raised hoverable w-100">
                              <div class="anim"></div><span>submit</span>
                            </button>
                          </form>
                          <!-- <p class="para-content">Don't have an account? <a href="signup.html">Sign up here</a> </p> -->
                        </div>

                      </div>
                    </div>
                  </div>
                  <!-- <div class="form-right p-0">

            </div> -->
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </section>
    <!-- //ecommerce single block -->
    <div class="display-ad" style="margin: 8px auto; display: block; text-align:center;">
      <!---728x90--->

    </div>
    <!-- footer -->
    <section class="w3l-footer-16">
  <div class="w3l-footer-16-main">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="row">
            <div class="col-lg-8 col-md-6 col-7 column pr-lg-0">
              <a class="logo" href="index.html"><span class="fa fa-window-restore logo-icon"
                  aria-hidden="true"></span><span class="ml-2"><span class="logo-let">Rent</span>Pe<p>
                     Products on Rent</p></span></a></a>
              <p class="mt-4">"From furniture and electronics to party supplies and heavy equipment, we make it easy to rent what you need, when you need it. Whether you're planning a one-time event or need temporary solutions, our rental service saves you money and space." </p>
            </div>
            <div class="col-lg-4 col-md-6 col-5 column pr-lg-0">
              <h3>Pages</h3>
              <ul class="footer-gd-16">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.html">Services</a></li>
               
                <li><a href="contact.html">Contact Us</a></li>
              </ul>
            </div>
          </div>
        </div>
    <!-- //footer -->

    <script>
      (function() {
        function c() {
          var b = a.contentDocument || a.contentWindow.document;
          if (b) {
            var d = b.createElement('script');
            d.innerHTML = "window.__CF$cv$params={r:'90b0b1200a7fe17d',t:'MTczODM5OTgwNS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='../../../../../../cdn-cgi/challenge-platform/h/b/scripts/jsd/6682e961b853/maind41d.js';document.getElementsByTagName('head')[0].appendChild(a);";
            b.getElementsByTagName('head')[0].appendChild(d)
          }
        }
        if (document.body) {
          var a = document.createElement('iframe');
          a.height = 1;
          a.width = 1;
          a.style.position = 'absolute';
          a.style.top = 0;
          a.style.left = 0;
          a.style.border = 'none';
          a.style.visibility = 'hidden';
          document.body.appendChild(a);
          if ('loading' !== document.readyState) c();
          else if (window.addEventListener) document.addEventListener('DOMContentLoaded', c);
          else {
            var e = document.onreadystatechange || function() {};
            document.onreadystatechange = function(b) {
              e(b);
              'loading' !== document.readyState && (document.onreadystatechange = e, c())
            }
          }
        }
      })();
    </script>
  </body>


  <!-- Mirrored from p.w3layouts.com/demosWTR/Freedom/04-01-2020/mend-freedom-demo_Free/540431521/web/ecommerce-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2025 08:50:46 GMT -->

</html>