<?php
session_start();
require './admin/class/atclass.php';
?>
<!doctype html>
<html lang="en">
  
<!-- Mirrored from p.w3layouts.com/demosWTR/Freedom/04-01-2020/mend-freedom-demo_Free/540431521/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2025 08:49:48 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Mend Home Maintenance & Service Category Responsive Web Template - Home : W3Layouts</title>
    <!-- web fonts -->
    <link href="http://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900&amp;display=swap" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Pacifico&amp;display=swap&amp;subset=cyrillic,cyrillic-ext,latin-ext,vietnamese" rel="stylesheet">
    <!-- //web fonts -->
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-freedom.css">
  </head>
  <body>
<script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/w3layouts_V2/vdo.ai.js?vdo=34");</script>-->
<div id="codefund"><!-- fallback content --></div>
<script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src='https://www.googletagmanager.com/gtag/js?id=G-98H8KRKT85'></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-98H8KRKT85');
</script>
<meta name="robots" content="noindex">
<body>
	<!-- Demo bar start -->
  <link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
<!-- New toolbar-->
<style>
* {
  box-sizing: border-box;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
}


#w3lDemoBar.w3l-demo-bar {
  top: 0;
  right: 0;
  bottom: 0;
  z-index: 9999;
  padding: 40px 5px;
  padding-top:70px;
  margin-bottom: 70px;
  background: #0D1326;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}

#w3lDemoBar.w3l-demo-bar a {
  display: block;
  color: #e6ebff;
  text-decoration: none;
  line-height: 24px;
  opacity: .6;
  margin-bottom: 20px;
  text-align: center;
}

#w3lDemoBar.w3l-demo-bar span.w3l-icon {
  display: block;
}

#w3lDemoBar.w3l-demo-bar a:hover {
  opacity: 1;
}

#w3lDemoBar.w3l-demo-bar .w3l-icon svg {
  color: #e6ebff;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons {
  margin-top: 30px;
  border-top: 1px solid #41414d;
  padding-top: 40px;
}
#w3lDemoBar.w3l-demo-bar .demo-btns {
  border-top: 1px solid #41414d;
  padding-top: 30px;
}
#w3lDemoBar.w3l-demo-bar .responsive-icons a span.fa {
  font-size: 26px;
}
#w3lDemoBar.w3l-demo-bar .no-margin-bottom{
  margin-bottom:0;
}
.toggle-right-sidebar span {
  background: #0D1326;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #e6ebff;
  border-radius: 50px;
  font-size: 26px;
  cursor: pointer;
  opacity: .5;
}
.pull-right {
  float: right;
  position: fixed;
  right: 0px;
  top: 70px;
  width: 90px;
  z-index: 99999;
  text-align: center;
}
/* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

#right-sidebar {
  width: 90px;
  position: fixed;
  height: 100%;
  z-index: 1000;
  right: 0px;
  top: 0;
  margin-top: 60px;
  -webkit-transition: all .5s ease-in-out;
  -moz-transition: all .5s ease-in-out;
  -o-transition: all .5s ease-in-out;
  transition: all .5s ease-in-out;
  overflow-y: auto;
}

/* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

.hide-right-bar-notifications {
  margin-right: -300px !important;
  -webkit-transition: all .3s ease-in-out;
  -moz-transition: all .3s ease-in-out;
  -o-transition: all .3s ease-in-out;
  transition: all .3s ease-in-out;
}



@media (max-width: 992px) {
  #w3lDemoBar.w3l-demo-bar a.desktop-mode{
      display: none;

  }
}
@media (max-width: 767px) {
  #w3lDemoBar.w3l-demo-bar a.tablet-mode{
      display: none;

  }
}
@media (max-width: 568px) {
  #w3lDemoBar.w3l-demo-bar a.mobile-mode{
      display: none;
  }
  #w3lDemoBar.w3l-demo-bar .responsive-icons {
      margin-top: 0px;
      border-top: none;
      padding-top: 0px;
  }
  #right-sidebar,.pull-right {
      width: 90px;
  }
  #w3lDemoBar.w3l-demo-bar .no-margin-bottom-mobile{
      margin-bottom: 0;
  }
}
</style>

</div>

<?php 
include './themepart/header.php'
?>
<section class="w3l-main-slider" id="home">
  <!-- main-slider -->
  <div class="companies20-content">
    <div class="companies-wrapper"></div>
    <div class="owl-one owl-carousel owl-theme">
      <div class="item">
        <li class="banner-view banner-top1 bg bg2">
          <div class="slider-info">
            <div class="banner-info">
              <div class="container">
                <div class="banner-info-bg">
                  <div class="row align-items-center py-lg-5 py-3">
                    <div class="col-lg-6 col-md-8 content-left">
                      <h3 lass="sub-title-top">Quality Products </h3>
                      <h3 lass="sub-title-top">& Service</h3>
                      
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </li>
      </div>
      <div class="item">
        <li class="banner-view banner-top3 bg bg2">
          <div class="slider-info">
            <div class="banner-info">
              <div class="container">
                <div class="banner-info-bg">
                  <div class="row align-items-center py-lg-5 py-3">
                    <div class="col-lg-6 col-md-8 content-left">
                      <h3 lass="sub-title-top">Explore Premium</h3>
                      <h3 lass="sub-title-top"> Products</h3>
                     
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </li>
      </div>
      <div class="item">
        <li class="banner-view banner-top2 bg bg2">
          <div class="slider-info">
            <div class="banner-info">
              <div class="container">
                <div class="banner-info-bg">
                  <div class="row align-items-center py-lg-5 py-3">
                    <div class="col-lg-6 col-md-8 content-left">
                      <h5 lass="sub-title-top">Furniture & Electronics </h5>
                      <h3 lass="sub-title-top"> Specialists! </h3>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>

  <script src="assets/js/owl.carousel.js"></script>

  <!-- script for -->
  <script>
    $(document).ready(function () {
      $('.owl-one').owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        responsiveClass: true,
        autoplay: false,
        autoplayTimeout: 5000,
        autoplaySpeed: 1000,
        autoplayHoverPause: false,
        responsive: {
          0: {
            items: 1,
            nav: false
          },
          480: {
            items: 1,
            nav: false
          },
          667: {
            items: 1,
            nav: true
          },
          1000: {
            items: 1,
            nav: true
          }
        }
      })
    })
  </script>
  <!-- //script -->
  <!-- /main-slider -->
</section>
<div class="display-ad" style="margin: 8px auto; display: block; text-align:center;">
        <!---728x90--->

    </div>
 
<div class="display-ad" style="margin: 8px auto; display: block; text-align:center;">
        <!---728x90--->

    </div>
<!-- index-block2 -->
<section class="w3l-index-block2">
  <div class="container py-3">
    <div class="heading text-center mx-auto">
      <h3 class="head">Furniture and Electronics for Office & Home </h3>
      <h6 class="my-3 head"> "Why Buy When You Can Rent?</h6>
    </div>
    <div class="row bottom_grids mt-5 pt-lg-3">
      <div class="col-lg-4 col-md-6">
        <div class="s-block">
          <a href="single.html" class="d-block">
            <img src="assets/images/image3.jpg" alt="" class="img-fluid" />
            <div class="p-4">
              <h3 class="mb-3">Furniture Services</h3>
              
            </div>
          </a>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 mt-md-0 mt-4">
        <div class="s-block">
          <a href="single.html" class="d-block">
            <img src="admin\uploads\electic.jpg" alt="" class="img-fluid" />
            <div class="p-4">
              <h3 class="mb-3">Electronics</h3>
             
            </div>
          </a>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 mx-auto mt-lg-0 mt-4">
        <div class="s-block">
          <a href="single.html" class="d-block">
            <img src="admin\uploads\Blog.jpg" alt="" class="img-fluid" />
            <div class="p-4">
              <h3 class="mb-3">Fitness</h3>
              
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
<div class="display-ad" style="margin: 8px auto; display: block; text-align:center;">
        <!---728x90--->

    </div>
<!-- /index-block2 -->
 <div class="w3l-index-block4 py-5">
   <div class="features-bg py-md-5">
     <!-- features15 block -->
     <div class="container py-md-3">
       <div class="heading text-center mx-auto">
         <h3 class="head">Quality is Our Passion</h3>
         
       </div>
       <div class="row">
         <div class="col-lg-4 col-md-6 features15-col-text">
           <a href="single.html" class="d-flex feature-unit align-items-center">
             <div class="col-3">
               <div class="features15-info">
                 <span class="fa fa-truck" aria-hidden="true"></span>
               </div>
             </div>
             <div class="col-9">
               <div class="features15-para">
                 <h4>We Deliver in Time</h4>
                 
               </div>
             </div>
           </a>
         </div>
         <div class="col-lg-4 col-md-6 features15-col-text">
           <a href="single.html" class="d-flex feature-unit align-items-center">
             <div class="col-3">
               <div class="features15-info">
                 <span class="fa fa-paint-brush" aria-hidden="true"></span>
               </div>
             </div>
             <div class="col-9">
               <div class="features15-para">
                 <h4>Technical Services</h4>
               
               </div>
             </div>
           </a>
         </div>
         <div class="col-lg-4 col-md-6 features15-col-text">
           <a href="single.html" class="d-flex feature-unit align-items-center">
             <div class="col-3">
               <div class="features15-info">
                 <span class="fa fa-wrench" aria-hidden="true"></span>
               </div>
             </div>
             <div class="col-9">
               <div class="features15-para">
                 <h4>Engineering Services</h4>
                 
               </div>
             </div>
           </a>
         </div>
       </div>
       <div class="row">
         <div class="col-lg-4 col-md-6 features15-col-text">
           <a href="single.html" class="d-flex feature-unit align-items-center">
             <div class="col-3">
               <div class="features15-info">
                 <span class="fa fa-cog" aria-hidden="true"></span>
               </div>
             </div>
             <div class="col-9">
               <div class="features15-para">
                 <h4>A Premium Service</h4>
                 
               </div>
             </div>
           </a>
         </div>
         <div class="col-lg-4 col-md-6 features15-col-text">
           <a href="single.html" class="d-flex feature-unit align-items-center">
             <div class="col-3">
               <div class="features15-info">
                 <span class="fa fa-line-chart" aria-hidden="true"></span>
               </div>
             </div>
             <div class="col-9">
               <div class="features15-para">
                 <h4>Express Service</h4>
                 
               </div>
             </div>
           </a>
         </div>
         <div class="col-lg-4 col-md-6 features15-col-text">
           <a href="single.html" class="d-flex feature-unit align-items-center">
             <div class="col-3">
               <div class="features15-info">
                 <span class="fa fa-thumbs-up" aria-hidden="true"></span>
               </div>
             </div>
             <div class="col-9">
               <div class="features15-para">
                 <h4>Maintenance</h4>
                 
               </div>
             </div>
           </a>
         </div>
       </div>
       <!-- features15 block -->
     </div>
   </div>
 </div>
<!-- content-with-photo17 -->
 
<!-- content-with-photo17 -->
 
<!-- subscribe section -->
 
<!-- //subscribe -->
<!-- footer -->
<?php include './themepart/footer.php' ?>
<!-- //footer -->

<script>(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'90b0b0b7ae60e1f5',t:'MTczODM5OTc4OS4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='../../../../../../cdn-cgi/challenge-platform/h/b/scripts/jsd/6682e961b853/maind41d.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();</script></body>


<!-- Mirrored from p.w3layouts.com/demosWTR/Freedom/04-01-2020/mend-freedom-demo_Free/540431521/web/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2025 08:50:13 GMT -->
</html>