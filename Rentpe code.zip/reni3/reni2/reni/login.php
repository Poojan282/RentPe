<?php
session_start();
require './admin/class/atclass.php';
if ($_POST) {
  $email = mysqli_real_escape_string($connection, $_POST['email']);
  $password = mysqli_real_escape_string($connection, $_POST['password']);
  $query = mysqli_query($connection, "select * from tbl_user where email='{$email}' and password='{$password}'");
  $count = mysqli_num_rows($query);
  $row = mysqli_fetch_array($query);

  if ($count > 0) {
    $_SESSION['id'] = $row['user_id'];
    $_SESSION['name'] = $row['user_name'];
    header("location:shop.php");
  } else {
    echo "<script>alert('Login Failed'); </script>";
  }
}
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from p.w3layouts.com/demosWTR/Freedom/04-01-2020/mend-freedom-demo_Free/540431521/web/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2025 08:50:39 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Mend Home Maintenance & Service Category Responsive Web Template - Login : W3Layouts</title>
  <!-- web fonts -->
  <link href="http://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900&amp;display=swap" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Pacifico&amp;display=swap&amp;subset=cyrillic,cyrillic-ext,latin-ext,vietnamese" rel="stylesheet">
  <!-- //web fonts -->
  <!-- Template CSS -->
  <!-- js -->
  <script type="text/javascript" src="./js/jquery-2.1.4.min.js"></script>
  <!-- //js -->
  <link rel="stylesheet" href="assets/css/style-freedom.css">
</head>

<body>
  <script src='../../../../../../../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
  <script src="../../../../../../../m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
  <script>
    (function() {
      if (typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
      }
    })();
  </script>
  <script>
    (function() {
      if (typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
      }
    })();
  </script>
  <script>
    (function() {
      if (typeof _bsa !== 'undefined' && _bsa) {
        // format, zoneKey, segment:value, options
        _bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
      }
    })();
  </script>
  <!--<script>(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//a.vdo.ai/core/w3layouts_V2/vdo.ai.js?vdo=34");</script>-->
  <div id="codefund"><!-- fallback content --></div>
  <script src="../../../../../../../codefund.io/properties/441/funder.js" async="async"></script>

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src='https://www.googletagmanager.com/gtag/js?id=G-98H8KRKT85'></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-98H8KRKT85');
  </script>
  <meta name="robots" content="noindex">

  <body>
    <!-- Demo bar start -->
    <link rel="stylesheet" href="../../../../../../assests/css/font-awesome.min.css">
    <!-- New toolbar-->
    <style>
      * {
        box-sizing: border-box;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
      }


      #w3lDemoBar.w3l-demo-bar {
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 9999;
        padding: 40px 5px;
        padding-top: 70px;
        margin-bottom: 70px;
        background: #0D1326;
        border-top-left-radius: 9px;
        border-bottom-left-radius: 9px;
      }

      #w3lDemoBar.w3l-demo-bar a {
        display: block;
        color: #e6ebff;
        text-decoration: none;
        line-height: 24px;
        opacity: .6;
        margin-bottom: 20px;
        text-align: center;
      }

      #w3lDemoBar.w3l-demo-bar span.w3l-icon {
        display: block;
      }

      #w3lDemoBar.w3l-demo-bar a:hover {
        opacity: 1;
      }

      #w3lDemoBar.w3l-demo-bar .w3l-icon svg {
        color: #e6ebff;
      }

      #w3lDemoBar.w3l-demo-bar .responsive-icons {
        margin-top: 30px;
        border-top: 1px solid #41414d;
        padding-top: 40px;
      }

      #w3lDemoBar.w3l-demo-bar .demo-btns {
        border-top: 1px solid #41414d;
        padding-top: 30px;
      }

      #w3lDemoBar.w3l-demo-bar .responsive-icons a span.fa {
        font-size: 26px;
      }

      #w3lDemoBar.w3l-demo-bar .no-margin-bottom {
        margin-bottom: 0;
      }

      .toggle-right-sidebar span {
        background: #0D1326;
        width: 50px;
        height: 50px;
        line-height: 50px;
        text-align: center;
        color: #e6ebff;
        border-radius: 50px;
        font-size: 26px;
        cursor: pointer;
        opacity: .5;
      }

      .pull-right {
        float: right;
        position: fixed;
        right: 0px;
        top: 70px;
        width: 90px;
        z-index: 99999;
        text-align: center;
      }

      /* ============================================================
RIGHT SIDEBAR SECTION
============================================================ */

      #right-sidebar {
        width: 90px;
        position: fixed;
        height: 100%;
        z-index: 1000;
        right: 0px;
        top: 0;
        margin-top: 60px;
        -webkit-transition: all .5s ease-in-out;
        -moz-transition: all .5s ease-in-out;
        -o-transition: all .5s ease-in-out;
        transition: all .5s ease-in-out;
        overflow-y: auto;
      }

      /* ============================================================
RIGHT SIDEBAR TOGGLE SECTION
============================================================ */

      .hide-right-bar-notifications {
        margin-right: -300px !important;
        -webkit-transition: all .3s ease-in-out;
        -moz-transition: all .3s ease-in-out;
        -o-transition: all .3s ease-in-out;
        transition: all .3s ease-in-out;
      }



      @media (max-width: 992px) {
        #w3lDemoBar.w3l-demo-bar a.desktop-mode {
          display: none;

        }
      }

      @media (max-width: 767px) {
        #w3lDemoBar.w3l-demo-bar a.tablet-mode {
          display: none;

        }
      }

      @media (max-width: 568px) {
        #w3lDemoBar.w3l-demo-bar a.mobile-mode {
          display: none;
        }

        #w3lDemoBar.w3l-demo-bar .responsive-icons {
          margin-top: 0px;
          border-top: none;
          padding-top: 0px;
        }

        #right-sidebar,
        .pull-right {
          width: 90px;
        }

        #w3lDemoBar.w3l-demo-bar .no-margin-bottom-mobile {
          margin-bottom: 0;
        }
      }
    </style>

    </div>


    <!-- login block -->
    <section class="w3l-form1">
      <div class="form">
        <div class="section">
          <div class="d-grid content-sec">
            <div class="form-left">
              <div class="container">
                <div class="sub-left-cont">
                  <div class="content-form p-md-5 p-4">
                    <div class="middle">
                      <h4>Member Login</h4>
                    </div>
                    <form action="login.php" method="post" id="myform" class="signin-form">
                      <div class="form-input">
                        <input type="email" name="email" placeholder="Email" required />
                      </div>
                      <div class="form-input">
                        <input type="password" name="password" placeholder="Password" required />
                      </div>
                      <label class="checkout">Remember me
                        <input type="checkbox">
                        <span class="checkmark"></span>
                      </label>
                      <button type="submit" class="button raised hoverable w-100">
                        <div class="anim"></div><span>Login</span>
                      </button>
                    </form>
                    <p class="para-content">Don't have an account? <a href="signup.php">Sign up here</a> </p><br>
                    <a href="forgotpassword.php">forgot Password</a>
                  </div>
                  <div class="text-left pl-md-5 pl-4">
                    <a href="index.php" class="button-btn btn">Back to Home</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-right p-0">

            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- //login block -->
    <!-- <script src="./mytool/jquery.validate.js"></script> -->
    <script src="./mytool/jquery-validate.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></Script>
    <script>
      $(document).ready(function() {
        $("#myform").validate();
      });
    </script>
    <style>
      .error {
        color: red;
      }
    </style>

    <!-- <script>
      $(document).ready(function() {
          $("#myform").validate({
            rules: {

              user_email: {
                required: true,
                email: true
              },
              user_password: {
                required: true,
              },


            },
            messages: {

              user_email: {
                required: "Please Enter Email",
              },

              user_password: {
                required: "Please Enter Password",


              },

            }
          });
        }

      );
    </script>
    <style>
      .error {
        color: red;
      }
    </style> -->
    <script>
      (function() {
        function c() {
          var b = a.contentDocument || a.contentWindow.document;
          if (b) {
            var d = b.createElement('script');
            d.innerHTML = "window.__CF$cv$params={r:'90b0b10d4e7ce1f5',t:'MTczODM5OTgwMi4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='../../../../../../cdn-cgi/challenge-platform/h/b/scripts/jsd/6682e961b853/maind41d.js';document.getElementsByTagName('head')[0].appendChild(a);";
            b.getElementsByTagName('head')[0].appendChild(d)
          }
        }
        if (document.body) {
          var a = document.createElement('iframe');
          a.height = 1;
          a.width = 1;
          a.style.position = 'absolute';
          a.style.top = 0;
          a.style.left = 0;
          a.style.border = 'none';
          a.style.visibility = 'hidden';
          document.body.appendChild(a);
          if ('loading' !== document.readyState) c();
          else if (window.addEventListener) document.addEventListener('DOMContentLoaded', c);
          else {
            var e = document.onreadystatechange || function() {};
            document.onreadystatechange = function(b) {
              e(b);
              'loading' !== document.readyState && (document.onreadystatechange = e, c())
            }
          }
        }
      })();
    </script>
  </body>


  <!-- Mirrored from p.w3layouts.com/demosWTR/Freedom/04-01-2020/mend-freedom-demo_Free/540431521/web/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Feb 2025 08:50:39 GMT -->

</html>