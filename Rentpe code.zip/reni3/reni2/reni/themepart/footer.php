<section class="w3l-footer-16">
  <div class="w3l-footer-16-main">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
          <div class="row">
            <div class="col-lg-8 col-md-6 col-7 column pr-lg-0">
              <a class="logo" href="index.html"><span class="fa fa-window-restore logo-icon"
                  aria-hidden="true"></span><span class="ml-2"><span class="logo-let">Rent</span>Pe<p>
                     Products on Rent</p></span></a></a>
              <p class="mt-4">"From furniture and electronics to party supplies and heavy equipment, we make it easy to rent what you need, when you need it. Whether you're planning a one-time event or need temporary solutions, our rental service saves you money and space." </p>
            </div>
            <div class="col-lg-4 col-md-6 col-5 column pr-lg-0">
              <h3>Pages</h3>
              <ul class="footer-gd-16">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="services.html">Services</a></li>
               
                <li><a href="contact.html">Contact Us</a></li>
              </ul>
            </div>
          </div>
        </div>
        
        

  <!-- move top -->
  <button onclick="topFunction()" id="movetop" title="Go to top">
    <span class="fa fa-angle-up"></span>
  </button>
  <script>
    // When the user scrolls down 20px from the top of the document, show the button
    window.onscroll = function () {
      scrollFunction()
    };

    function scrollFunction() {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("movetop").style.display = "block";
      } else {
        document.getElementById("movetop").style.display = "none";
      }
    }

    // When the user clicks on the button, scroll to the top of the document
    function topFunction() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    }
  </script>
  <!-- //move top -->
  <script>
    $(function () {
      $('.navbar-toggler').click(function () {
        $('body').toggleClass('noscroll');
      })
    });
  </script>
</section>