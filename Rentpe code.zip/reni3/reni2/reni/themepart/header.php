<section class="w3l-bootstrap-header">
  <nav class="navbar navbar-expand-lg navbar-light sub-content">
    <div class="container">
      <a class="navbar-brand" href="index.html"><span class="fa fa-window-restore logo-icon"
          aria-hidden="true"></span><span class="left-logo"><span class="logo-let">Rent</span>Pe<p>
            Products on Rent</p></span></a>
      <!-- if logo is image enable this   
    <a class="navbar-brand" href="#index.html">
        <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
    </a> -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>




          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">
              Category
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <?php
              $categoryq = mysqli_query($connection, "select * from tbl_category");
              while ($cdata = mysqli_fetch_array($categoryq)) {
                echo  "<a class='dropdown-item' href='shop.php?categoryid={$cdata['category_id']}'>{$cdata['category_name']}</a>";
              }
              ?>

            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="shop.php">Shop</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>

         

          <?php if (isset($_SESSION['id'])) { ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                Account
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="nav-link" href="checkout-form.php"> Cart</a>
              <a class="nav-link" href="view-feedback.php"> View Feedback</a>
                <a class="nav-link" href="changepassword.php">Change Password</a>
                 <a class="nav-link" href="logout.php">Logout</a>

              </div>
            </li>
          <?php } else {
          ?>
 <li class="nav-item">
            <a class="nav-link" href="login.php">Log In</a>
          </li>
          <?php
          } ?>

        </ul>


      </div>
      <!-- Button trigger modal -->

      <!-- Modal -->

    </div>
  </nav>
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
</section>